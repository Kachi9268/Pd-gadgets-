
import React from 'react';
import { Link } from 'react-router-dom';
import { 
  MessageSquare, 
  CheckCircle, 
  TruckIcon, 
  HeadphonesIcon, 
  ArrowRight,
  Clock,
  ThumbsUp,
  Zap,
  HelpCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProductCard from '@/components/ProductCard';
import { getFeaturedProducts } from '@/data/products';
import { AnimatedSection } from '@/utils/useScrollAnimation';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import AnimatedBackground from '@/components/AnimatedBackground';

const HomePage = () => {
  const featuredProducts = getFeaturedProducts();

  return (
    <div className="flex flex-col">
      {/* Hero Section with Laptop Image Background */}
      <section className="relative bg-gradient-to-r from-primary/90 to-primary/95 py-16 md:py-24 text-white hero-background overflow-hidden">
        <AnimatedBackground imageBg={true} />
        <div className="container-custom relative z-10 hero-content">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <AnimatedSection className="space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Upgrade Your Tech.<br />PD Gadget Has You Covered.
              </h1>
              <p className="text-lg md:text-xl opacity-90">
                Shop the latest smartphones, laptops, accessories & more.
              </p>
              <div className="flex flex-wrap gap-4 pt-2">
                <Link to="/products">
                  <Button variant="secondary" size="lg" className="font-medium">
                    Explore Products
                  </Button>
                </Link>
                <a 
                  href={`https://wa.me/2349135107029`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-whatsapp hover:bg-whatsapp/90 text-white rounded-md font-medium transition-colors"
                >
                  <MessageSquare size={20} />
                  Chat with Us on WhatsApp
                </a>
              </div>
            </AnimatedSection>
            <div className="hidden md:block">
              <AnimatedSection>
                <img 
                  src="https://images.unsplash.com/photo-1566647387313-9fda80664848?w=500&auto=format&fit=crop" 
                  alt="Latest Tech Gadgets" 
                  className="rounded-lg shadow-xl"
                />
              </AnimatedSection>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <AnimatedSection className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Featured Products</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Discover our selection of premium tech gadgets, from the latest smartphones to powerful laptops and must-have accessories.
            </p>
          </AnimatedSection>
          
          <div className="product-grid">
            {featuredProducts.map((product, index) => (
              <AnimatedSection key={product.id} delay={index * 100}>
                <ProductCard product={product} />
              </AnimatedSection>
            ))}
          </div>
          
          <AnimatedSection className="text-center mt-12">
            <Link to="/products">
              <Button variant="outline" size="lg">View All Products</Button>
            </Link>
          </AnimatedSection>
        </div>
      </section>

      {/* How It Works */}
      <AnimatedSection className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">How It Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Shopping with PD Gadget is simple and straightforward. Here's how to get started:
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <AnimatedSection delay={100} className="bg-gray-50 p-8 rounded-lg text-center hover:shadow-md transition-shadow">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap size={28} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">1. Browse Trending Gadgets</h3>
              <p className="text-gray-600">
                Explore our curated selection of the latest tech gadgets and accessories.
              </p>
            </AnimatedSection>
            
            <AnimatedSection delay={200} className="bg-gray-50 p-8 rounded-lg text-center hover:shadow-md transition-shadow">
              <div className="bg-whatsapp/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageSquare size={28} className="text-whatsapp" />
              </div>
              <h3 className="text-xl font-semibold mb-2">2. Click 'Order Now'</h3>
              <p className="text-gray-600">
                Chat with us directly on WhatsApp to place your order and discuss any questions.
              </p>
            </AnimatedSection>
            
            <AnimatedSection delay={300} className="bg-gray-50 p-8 rounded-lg text-center hover:shadow-md transition-shadow">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <TruckIcon size={28} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">3. Receive Fast Delivery</h3>
              <p className="text-gray-600">
                Get your gadgets delivered quickly and securely to your doorstep.
              </p>
            </AnimatedSection>
          </div>
        </div>
      </AnimatedSection>

      {/* Why Shop With Us */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <AnimatedSection className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Shop With Us</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              At PD Gadget, we're committed to providing the best shopping experience with quality products and reliable service.
            </p>
          </AnimatedSection>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <AnimatedSection delay={100} className="bg-white p-8 rounded-lg text-center hover:shadow-md transition-shadow">
              <CheckCircle size={48} className="text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Original Gadgets Only</h3>
              <p className="text-gray-600">
                All our products are genuine and come with manufacturer warranty.
              </p>
            </AnimatedSection>
            
            <AnimatedSection delay={200} className="bg-white p-8 rounded-lg text-center hover:shadow-md transition-shadow">
              <TruckIcon size={48} className="text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Fast Nationwide Delivery</h3>
              <p className="text-gray-600">
                Get your gadgets delivered quickly and safely to your doorstep.
              </p>
            </AnimatedSection>
            
            <AnimatedSection delay={300} className="bg-white p-8 rounded-lg text-center hover:shadow-md transition-shadow">
              <MessageSquare size={48} className="text-whatsapp mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">WhatsApp Ordering</h3>
              <p className="text-gray-600">
                Simple and convenient ordering process through WhatsApp.
              </p>
            </AnimatedSection>
            
            <AnimatedSection delay={400} className="bg-white p-8 rounded-lg text-center hover:shadow-md transition-shadow">
              <ThumbsUp size={48} className="text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">1,000+ Happy Customers</h3>
              <p className="text-gray-600">
                Join our growing community of satisfied customers.
              </p>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Delivery & Payment Section */}
      <AnimatedSection className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Delivery & Payment</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We make getting your tech gadgets as convenient as possible.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <AnimatedSection delay={100} className="bg-gray-50 p-8 rounded-lg hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold mb-4 flex items-center">
                <TruckIcon className="mr-2 text-primary" size={24} />
                Nationwide Delivery
              </h3>
              <p className="text-gray-600 mb-4">
                We offer fast nationwide delivery within 1-3 working days, ensuring your tech arrives safely and on time.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  Lagos & Abuja: 1-2 days
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  Other major cities: 2-3 days
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  Remote locations: 3-5 days
                </li>
              </ul>
            </AnimatedSection>
            
            <AnimatedSection delay={200} className="bg-gray-50 p-8 rounded-lg hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold mb-4 flex items-center">
                <Clock className="mr-2 text-primary" size={24} />
                Payment Options
              </h3>
              <p className="text-gray-600 mb-4">
                We offer flexible payment methods to suit your preferences and ensure a smooth shopping experience.
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  Bank transfer (preferred)
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  Payment on delivery (select locations)
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  All orders are confirmed via WhatsApp before shipping
                </li>
              </ul>
            </AnimatedSection>
          </div>
        </div>
      </AnimatedSection>

      {/* Testimonials - Keep as is */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <AnimatedSection className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">What Our Customers Say</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Don't just take our word for it. Hear from our satisfied customers.
            </p>
          </AnimatedSection>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <AnimatedSection delay={100} className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="bg-gray-200 w-12 h-12 rounded-full flex items-center justify-center">
                  <span className="text-xl font-semibold">JO</span>
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold">John Okafor</h4>
                  <div className="flex text-yellow-400">
                    ★★★★★
                  </div>
                </div>
              </div>
              <p className="text-gray-600">
                "The delivery was super fast, and the product was exactly as described. Will definitely shop here again!"
              </p>
            </AnimatedSection>
            
            <AnimatedSection delay={200} className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="bg-gray-200 w-12 h-12 rounded-full flex items-center justify-center">
                  <span className="text-xl font-semibold">SA</span>
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold">Sarah Ahmed</h4>
                  <div className="flex text-yellow-400">
                    ★★★★★
                  </div>
                </div>
              </div>
              <p className="text-gray-600">
                "I was hesitant to buy my iPhone online, but PD Gadget made the process seamless. Great customer service!"
              </p>
            </AnimatedSection>
            
            <AnimatedSection delay={300} className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="bg-gray-200 w-12 h-12 rounded-full flex items-center justify-center">
                  <span className="text-xl font-semibold">DO</span>
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold">David Okonkwo</h4>
                  <div className="flex text-yellow-400">
                    ★★★★★
                  </div>
                </div>
              </div>
              <p className="text-gray-600">
                "The laptop I bought from PD Gadget is top-notch. They were responsive on WhatsApp and very professional."
              </p>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* FAQs Section */}
      <AnimatedSection className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Find answers to common questions about our products and services.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <AnimatedSection delay={100} className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold mb-2 flex items-center">
                <HelpCircle size={20} className="text-primary mr-2" />
                How long does delivery take?
              </h3>
              <p className="text-gray-600">
                Delivery typically takes 1-3 business days for major cities, and 3-5 days for remote locations. We'll provide tracking information once your order is shipped.
              </p>
            </AnimatedSection>
            
            <AnimatedSection delay={200} className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold mb-2 flex items-center">
                <HelpCircle size={20} className="text-primary mr-2" />
                Is payment on delivery available?
              </h3>
              <p className="text-gray-600">
                Yes, we offer payment on delivery in select locations including Lagos, Abuja, and other major cities. Bank transfer is also available and preferred.
              </p>
            </AnimatedSection>
            
            <AnimatedSection delay={300} className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold mb-2 flex items-center">
                <HelpCircle size={20} className="text-primary mr-2" />
                Are the gadgets brand new or UK used?
              </h3>
              <p className="text-gray-600">
                We clearly specify the condition of each product. We offer both brand new products with full warranty and premium UK/US used gadgets in excellent condition at more affordable prices.
              </p>
            </AnimatedSection>
            
            <AnimatedSection delay={400} className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold mb-2 flex items-center">
                <HelpCircle size={20} className="text-primary mr-2" />
                Do you offer warranty on gadgets?
              </h3>
              <p className="text-gray-600">
                Yes, all brand new products come with the manufacturer's warranty. UK/US used products come with our shop warranty of 3-6 months depending on the item.
              </p>
            </AnimatedSection>
          </div>
        </div>
      </AnimatedSection>

      {/* Mini Blog Section */}
      <AnimatedSection className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Gadget Tips & Tricks</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Stay updated with the latest tech advice and insights.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <AnimatedSection delay={100}>
              <Card>
                <CardHeader>
                  <CardTitle>5 Essential Gadgets to Boost Productivity</CardTitle>
                  <CardDescription>May 10, 2025</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video bg-gray-100 rounded-md mb-4 overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1588058365548-9efe5acb8077?w=500&auto=format&fit=crop" 
                      alt="Productivity Gadgets" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="text-gray-600">
                    Discover the must-have tech tools that can dramatically improve your work efficiency and help you get more done in less time.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link to="#" className="text-primary flex items-center hover:underline font-medium">
                    Read More <ArrowRight size={16} className="ml-1" />
                  </Link>
                </CardFooter>
              </Card>
            </AnimatedSection>
            
            <AnimatedSection delay={200}>
              <Card>
                <CardHeader>
                  <CardTitle>How to Maximize Your Phone's Battery Life</CardTitle>
                  <CardDescription>May 5, 2025</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video bg-gray-100 rounded-md mb-4 overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&auto=format&fit=crop" 
                      alt="Phone Battery" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="text-gray-600">
                    Learn practical tips and settings adjustments that can help you get the most out of your smartphone's battery throughout the day.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link to="#" className="text-primary flex items-center hover:underline font-medium">
                    Read More <ArrowRight size={16} className="ml-1" />
                  </Link>
                </CardFooter>
              </Card>
            </AnimatedSection>
          </div>
        </div>
      </AnimatedSection>

      {/* CTA Section */}
      <AnimatedSection className="py-16 bg-primary text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Upgrade Your Tech?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Browse our wide selection of premium gadgets or chat with us directly for personalized recommendations.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/products">
              <Button variant="secondary" size="lg" className="font-medium">
                Explore Products
              </Button>
            </Link>
            <a 
              href={`https://wa.me/2349135107029`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-whatsapp hover:bg-whatsapp/90 text-white rounded-md font-medium transition-colors"
            >
              <MessageSquare size={20} />
              Chat with Us on WhatsApp
            </a>
          </div>
        </div>
      </AnimatedSection>
    </div>
  );
};

export default HomePage;
