
import React from 'react';
import { Phone, MessageSquare, Instagram, Mail, MapPin } from 'lucide-react';

const ContactPage = () => {
  return (
    <div className="py-12">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold mb-4">Contact Us</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We're here to help! Reach out to us with any questions or inquiries about our products.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="bg-white rounded-lg shadow-sm p-8">
            <h2 className="text-2xl font-semibold mb-6">Get in Touch</h2>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="bg-primary/10 p-3 rounded-full">
                  <Phone size={24} className="text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Phone</h3>
                  <p className="text-gray-600">
                    <a href="tel:+2349135107029" className="hover:text-primary">
                      +234 913 510 7029
                    </a>
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-whatsapp/10 p-3 rounded-full">
                  <MessageSquare size={24} className="text-whatsapp" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">WhatsApp</h3>
                  <p className="text-gray-600">
                    <a 
                      href={`https://wa.me/2349135107029`}
                      target="_blank"
                      rel="noreferrer"
                      className="hover:text-whatsapp"
                    >
                      +234 913 510 7029
                    </a>
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-primary/10 p-3 rounded-full">
                  <Mail size={24} className="text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Email</h3>
                  <p className="text-gray-600">
                    <a href="mailto:info@pdgadget.com" className="hover:text-primary">
                      info@pdgadget.com
                    </a>
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-primary/10 p-3 rounded-full">
                  <Instagram size={24} className="text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Instagram</h3>
                  <p className="text-gray-600">
                    <a 
                      href="https://instagram.com/pdgadget"
                      target="_blank"
                      rel="noreferrer"
                      className="hover:text-primary"
                    >
                      @pdgadget
                    </a>
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-primary/10 p-3 rounded-full">
                  <MapPin size={24} className="text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Location</h3>
                  <p className="text-gray-600">
                    Lagos, Nigeria
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* CTA / Image */}
          <div className="bg-gray-50 rounded-lg p-8 flex flex-col justify-center">
            <div className="text-center space-y-6">
              <h2 className="text-2xl font-semibold">Ready to Order?</h2>
              <p className="text-gray-600">
                Connect with us on WhatsApp for a fast and personalized shopping experience. We typically respond within minutes!
              </p>
              <a 
                href={`https://wa.me/2349135107029`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-whatsapp hover:bg-whatsapp/90 text-white rounded-md font-medium transition-colors"
              >
                <MessageSquare size={20} />
                Start WhatsApp Chat
              </a>
              
              <div className="pt-8">
                <img 
                  src="https://images.unsplash.com/photo-1556745753-b2904692b3cd?w=500&auto=format&fit=crop" 
                  alt="Customer Support" 
                  className="rounded-lg mx-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
