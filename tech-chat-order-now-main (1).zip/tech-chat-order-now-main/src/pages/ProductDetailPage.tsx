
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MessageSquare, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { getProductBySlug } from '@/data/products';

const ProductDetailPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const product = getProductBySlug(slug || '');
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  
  useEffect(() => {
    if (!product) {
      navigate('/products');
    }
    // Reset image index when product changes
    setActiveImageIndex(0);
  }, [product, navigate]);
  
  if (!product) {
    return null;
  }

  const handlePrevImage = () => {
    setActiveImageIndex((prevIndex) => 
      prevIndex === 0 ? (product.images?.length || 1) - 1 : prevIndex - 1
    );
  };

  const handleNextImage = () => {
    setActiveImageIndex((prevIndex) => 
      prevIndex === (product.images?.length || 1) - 1 ? 0 : prevIndex + 1
    );
  };

  const handleThumbnailClick = (index: number) => {
    setActiveImageIndex(index);
  };

  const handleWhatsAppOrder = () => {
    const message = `Hello PD Gadget, I'm interested in the *${product.name}*. Here's the product link: ${window.location.href}`;
    const whatsappUrl = `https://wa.me/2349135107029?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="py-12">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            {/* Main Image */}
            <div className="relative bg-gray-100 rounded-lg overflow-hidden h-[400px] flex items-center justify-center">
              <img 
                src={product.images?.[activeImageIndex] || product.image} 
                alt={product.name} 
                className="object-contain h-full w-full"
              />
              
              {/* Navigation Buttons */}
              {(product.images?.length || 0) > 1 && (
                <>
                  <button 
                    onClick={handlePrevImage}
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full p-2 hover:bg-white transition-colors"
                    aria-label="Previous image"
                  >
                    <ChevronLeft size={20} />
                  </button>
                  <button 
                    onClick={handleNextImage}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full p-2 hover:bg-white transition-colors"
                    aria-label="Next image"
                  >
                    <ChevronRight size={20} />
                  </button>
                </>
              )}
            </div>
            
            {/* Thumbnails */}
            {product.images && product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2">
                {product.images.map((image, index) => (
                  <button 
                    key={index}
                    className={`w-20 h-20 rounded-md overflow-hidden flex-shrink-0 border-2 ${activeImageIndex === index ? 'border-primary' : 'border-transparent'}`}
                    onClick={() => handleThumbnailClick(index)}
                  >
                    <img 
                      src={image} 
                      alt={`${product.name} thumbnail ${index + 1}`} 
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>
          
          {/* Product Details */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold">{product.name}</h1>
              <div className="flex flex-wrap gap-2 mt-2">
                {product.tags?.map((tag, index) => (
                  <Badge key={index} variant="secondary">{tag}</Badge>
                ))}
              </div>
            </div>
            
            <div className="text-3xl font-bold text-primary">
              ₦{product.price.toLocaleString()}
            </div>
            
            <div className="prose max-w-none">
              <p className="text-gray-700">{product.description}</p>
            </div>
            
            {/* Specifications */}
            {product.specifications && (
              <div className="border rounded-lg overflow-hidden">
                <div className="bg-gray-50 p-4 border-b">
                  <h3 className="font-semibold">Specifications</h3>
                </div>
                <div className="p-4">
                  <dl className="space-y-2">
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <div key={key} className="grid grid-cols-3 gap-4">
                        <dt className="font-medium text-gray-700">{key}</dt>
                        <dd className="col-span-2 text-gray-600">{value}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              </div>
            )}
            
            {/* Order Button */}
            <button 
              onClick={handleWhatsAppOrder}
              className="w-full btn-whatsapp flex justify-center items-center py-3 text-lg"
            >
              <MessageSquare size={20} className="mr-2" />
              Order Now on WhatsApp
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
