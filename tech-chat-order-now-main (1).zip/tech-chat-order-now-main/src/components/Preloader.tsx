
import React, { useEffect, useState } from 'react';

const Preloader: React.FC = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if this is the first visit to the site
    const isFirstVisit = !sessionStorage.getItem('hasVisited');
    
    if (!isFirstVisit) {
      setLoading(false);
      return;
    }
    
    // Mark as visited
    sessionStorage.setItem('hasVisited', 'true');
    
    // Simulate loading time (minimum of 1 second)
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  if (!loading) return null;

  return (
    <div className="fixed inset-0 bg-white dark:bg-gray-900 z-50 flex items-center justify-center transition-opacity duration-500">
      <div className="flex flex-col items-center">
        <div className="w-40 h-64 relative">
          {/* Phone outline */}
          <svg viewBox="0 0 100 160" className="w-full h-full">
            {/* Phone body */}
            <rect
              x="10"
              y="5"
              width="80"
              height="150"
              rx="10"
              className="fill-none stroke-primary stroke-2"
            />
            
            {/* Phone screen */}
            <rect
              x="15"
              y="15"
              width="70"
              height="130"
              rx="3"
              className="fill-gray-100 dark:fill-gray-800"
            />
            
            {/* Loading bar background */}
            <rect
              x="20"
              y="80"
              width="60"
              height="10"
              rx="5"
              className="fill-gray-200 dark:fill-gray-700"
            />
            
            {/* Animated loading bar */}
            <rect
              x="20"
              y="80"
              width="60"
              height="10"
              rx="5"
              className="fill-primary animate-loading-bar"
            >
              <animate
                attributeName="width"
                values="0;60"
                dur="2s"
                repeatCount="indefinite"
              />
            </rect>
            
            {/* Home button */}
            <circle
              cx="50"
              cy="155"
              r="7"
              className="fill-none stroke-primary stroke-1"
            />
          </svg>
        </div>
        <p className="mt-4 font-medium text-primary animate-pulse">
          Loading PD Gadget...
        </p>
      </div>
    </div>
  );
};

export default Preloader;
