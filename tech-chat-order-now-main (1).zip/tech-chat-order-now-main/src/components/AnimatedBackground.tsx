
import React, { useEffect, useRef } from 'react';

interface AnimatedBackgroundProps {
  className?: string;
  imageBg?: boolean;
}

const AnimatedBackground: React.FC<AnimatedBackgroundProps> = ({ className = '', imageBg = false }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    // If we're using an image background instead of particles, don't run the particle animation
    if (imageBg) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Particle system - Define particles array before using it
    const particles: Particle[] = [];
    const particleCount = 120; // We'll adjust this based on canvas width later
    
    class Particle {
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      opacity: number;

      constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.size = Math.random() * 1.5 + 0.5;
        this.speedX = (Math.random() - 0.5) * 0.3;
        this.speedY = (Math.random() - 0.5) * 0.3;
        this.opacity = Math.random() * 0.5 + 0.2;
      }

      update() {
        if (this.x < 0 || this.x > canvas.width) this.speedX *= -1;
        if (this.y < 0 || this.y > canvas.height) this.speedY *= -1;

        this.x += this.speedX;
        this.y += this.speedY;
      }

      draw() {
        if (!ctx) return;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${this.opacity})`;
        ctx.fill();
      }
    }

    function initParticles() {
      // Clear the particles array
      particles.length = 0;
      // Calculate responsive particle count based on canvas width
      const responsiveCount = Math.min(Math.floor(canvas.width / 15), 120);
      // Add new particles
      for (let i = 0; i < responsiveCount; i++) {
        particles.push(new Particle());
      }
    }

    // Resize handler
    const handleResize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      initParticles(); // Now this call is safe
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    // Connections between particles
    function drawConnections() {
      if (!ctx) return;
      
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          const maxDistance = canvas.width > 768 ? 100 : 70;
          
          if (distance < maxDistance) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(255, 255, 255, ${0.1 * (1 - distance / maxDistance)})`;
            ctx.lineWidth = 0.5;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }
    }

    // Animation loop
    function animate() {
      if (!ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach((particle) => {
        particle.update();
        particle.draw();
      });
      
      drawConnections();
      
      requestAnimationFrame(animate);
    }

    animate();

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [imageBg]);

  // If using image background, return an empty canvas (we'll use CSS background instead)
  if (imageBg) {
    return (
      <div 
        className={`absolute inset-0 w-full h-full ${className}`}
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=1500&auto=format&fit=crop")', 
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          opacity: 0.35,
          pointerEvents: 'none'
        }}
      />
    );
  }

  return (
    <canvas 
      ref={canvasRef} 
      className={`absolute inset-0 w-full h-full ${className}`}
      style={{ pointerEvents: 'none' }}
    />
  );
};

export default AnimatedBackground;
