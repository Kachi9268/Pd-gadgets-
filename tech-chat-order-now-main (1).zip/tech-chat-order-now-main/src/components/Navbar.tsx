
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Instagram, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container-custom flex items-center justify-between h-16">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <span className="text-2xl font-bold text-primary">PD Gadget</span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8">
          <Link to="/" className="font-medium hover:text-primary">
            Home
          </Link>
          <Link to="/products" className="font-medium hover:text-primary">
            Products
          </Link>
          <Link to="/contact" className="font-medium hover:text-primary">
            Contact
          </Link>
          <a 
            href="https://instagram.com/pdgadget"
            target="_blank"
            rel="noreferrer"
            className="text-gray-700 hover:text-primary"
          >
            <Instagram size={20} />
          </a>
          <a 
            href={`https://wa.me/2349135107029`}
            target="_blank"
            rel="noreferrer"
            className="btn-whatsapp"
          >
            <MessageSquare size={18} />
            <span>Chat with us</span>
          </a>
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden">
          <button onClick={toggleMobileMenu} className="text-gray-700">
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white p-4 border-t">
          <div className="flex flex-col space-y-4">
            <Link 
              to="/" 
              className="font-medium hover:text-primary py-2" 
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link 
              to="/products" 
              className="font-medium hover:text-primary py-2" 
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Products
            </Link>
            <Link 
              to="/contact" 
              className="font-medium hover:text-primary py-2" 
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Contact
            </Link>
            <div className="flex items-center space-x-4 pt-2">
              <a 
                href="https://instagram.com/pdgadget"
                target="_blank"
                rel="noreferrer"
                className="text-gray-700 hover:text-primary"
              >
                <Instagram size={20} />
              </a>
              <a 
                href={`https://wa.me/2349135107029`}
                target="_blank"
                rel="noreferrer"
                className="btn-whatsapp"
              >
                <MessageSquare size={18} />
                <span>Chat with us</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
